class Config:

    SECRET_KEY = "financial_wellness_bot"

    SQLALCHEMY_DATABASE_URI = "sqlite:///financial_bot.db"

    SQLALCHEMY_TRACK_MODIFICATIONS = False